#include <iostream>

using namespace std;

int euclidsAlgo(int m, int n)
{
    int remainder;
    do
    {
        remainder = m % n;
        cout << "\ngcd(" << m << ", " << n << ") = gcd (" << n << ", " << "(" << m << " % " << n << "))";
        m = n;
        n = remainder;
    } while (n != 0);
    cout << endl << m;
    return m;
}

int extendedEuclidsAlgo(int m, int n, int *x, int *y)
{
    if (n == 0) //base case
    {
        *x = 1;
        *y = 0;
        return m;
    }
    /*
    recursive call to find the GCD of two numbers
    and store their values in variables x and y.
    The value returned by this function is the greatest common divisor of a and b
    which can be found using the formula: g=gcd(a,b)=gcd(b%a,a).
    */
    int xStorage, yStorage; //stores the resulting coefficients

    int gcd = extendedEuclidsAlgo(n, m % n, &xStorage, &yStorage); // euclid's takes over

    *x = yStorage;
    *y = xStorage - (n / m) * yStorage;
    /*
        goal: figure out what the fuck sis going on 

        x as a pointer holds 
    */

    return gcd;
}

int consecutiveIntCheckAlgorithm(int m, int n)
{
    int t = min(m, n);
    do
    {
        if ((m % t) == 0)
        {
            if ((n % t) == 0)
                return t;
        }
        else
        {
            t -= 1;
        }
    } while (t > 0);

    return 1; //if no common factor is found
}