#include <iostream>
#include <cstring>



using namespace std;

int main()
{
    cout << string(9, "*") << endl;

    return 0;
}